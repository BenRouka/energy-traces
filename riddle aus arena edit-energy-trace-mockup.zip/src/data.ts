export type TraceNodeType = "src" | "form" | "sys";

export interface Lane {
  title: string;
  acc: boolean;
  nodes: [TraceNodeType, string][];
  outs: [string, string][];
}

export interface Riddle {
  q: string;
  a: [string, string][];
  c: string;
  h: string[];
  nd: string[];
}

export interface CaseData {
  n: string;
  t: string;
  intro: string;
  impulses?: [string, string][];
  steps?: [string, string][];
  obs: string[];
  riddle: Riddle;
  res: {
    title: string;
    p: string[];
    terms: [string, string, string][];
  };
  trace: {
    lanes: Lane[];
    concl: string;
  };
  done: string;
}

export const CASES: Record<number, CaseData> = {
  1: {
    n: "01",
    t: "Bewegungsspiel",
    intro:
      "Was passiert, wenn ihr euch bewegt? Findet heraus, woher die Energie für euren Körper kommt.",
    impulses: [
      ["Hüpft.", "Springt 30 Sekunden auf der Stelle."],
      ["Schüttelt euch.", "Arme, Beine, Schultern einmal gründlich lockern."],
      ["Stampft.", "Fest mit den Füßen auf den Boden."],
      ["Tor schießen.", "Stellt euch einen Ball vor und schießt kräftig."],
      ["Dreht euch.", "Einmal langsam um die eigene Achse."],
      ["Klatscht.", "Im gemeinsamen Rhythmus klatschen."],
    ],
    obs: [
      "Unsere Muskeln arbeiten.",
      "Wir werden warm.",
      "Unser Herz schlägt schneller.",
      "Wir atmen schneller.",
      "Wir nehmen Sauerstoff auf.",
      "Wir geben CO₂ ab.",
      "Wir bewegen die Luft.",
      "Es entsteht Schall.",
    ],
    riddle: {
      q: "Woher kommt die Energie für eure Bewegung?",
      a: [
        ["A", "Aus der Nahrung"],
        ["B", "Aus dem Sauerstoff"],
        ["C", "Aus der Umgebungsluft"],
      ],
      c: "A",
      h: [
        "Ihr habt die Energie nicht selbst erzeugt.",
        "Sie steckt zunächst in energiereichen Stoffen.",
        "Euer Körper wandelt sie unter anderem in Bewegung und Wärme um.",
      ],
      nd: [
        "Noch nicht.",
        "Ein Hinweis könnte helfen.",
        "Unterscheidet zwischen Energiequelle und einem Stoff, der am Stoffwechsel beteiligt ist.",
      ],
    },
    res: {
      title: "Die Spur beginnt bei der Nahrung.",
      p: [
        "Die Energie stammt aus der <strong>chemischen Energie energiereicher Stoffe</strong>, die ihr über die Nahrung aufnehmt.",
        "Im Stoffwechsel wird diese Energie umgewandelt. Dabei entstehen <strong>Bewegung</strong> und <strong>Wärme</strong>.",
        "Sauerstoff ist am Stoffwechsel beteiligt, ist aber selbst nicht die Energiequelle.",
      ],
      terms: [
        [
          "chemisch",
          "chemische Energie",
          "In welchen Lebensmitteln steckt besonders viel chemisch gespeicherte Energie?",
        ],
        [
          "kinetisch",
          "Bewegungsenergie",
          "Wann besitzt ein Körper besonders viel Bewegungsenergie?",
        ],
        [
          "thermisch",
          "thermische Energie",
          "Wo spürt ihr die thermische Energie eures Körpers?",
        ],
      ],
    },
    trace: {
      lanes: [
        {
          title: "Vom Sonnenlicht zur Bewegung",
          acc: true,
          nodes: [
            ["src", "Sonne"],
            ["form", "Strahlungsenergie"],
            ["sys", "Pflanze"],
            ["form", "Nahrung · chemische Energie"],
            ["sys", "Körper"],
          ],
          outs: [
            ["Bewegung", "kinetische Energie"],
            ["Wärme", "thermische Energie"],
          ],
        },
      ],
      concl:
        "Die Energie verschwindet nicht. Sie wird <em>übertragen</em> und <em>umgewandelt</em>.",
    },
    done: "Nahrung → Körper → Bewegung + Wärme",
  },
  2: {
    n: "02",
    t: "Glühbirne vs. LED",
    intro:
      "Zwei Lampen bekommen dieselbe elektrische Energie. Doch sie verteilen diese völlig unterschiedlich.",
    steps: [
      [
        "Glühbirne",
        "Beobachtet das Licht und spürt mit sicherem Abstand, wie heiß sie wird.",
      ],
      [
        "LED",
        "Gleicher Abstand bei der LED. Sie bleibt deutlich kühler.",
      ],
      ["Vergleichen", "Welche Lampe nutzt die Energie besser für Licht?"],
    ],
    obs: [
      "Beide Lampen geben Licht ab.",
      "Beide benötigen elektrische Energie.",
      "Die Glühbirne wird sehr heiß.",
      "Die LED bleibt meist deutlich kühler.",
      "Ein Teil der Energie wird zu Strahlungsenergie (Licht).",
      "Ein Teil wird zu thermischer Energie (Wärme).",
      "Die Energie verschwindet nicht.",
    ],
    riddle: {
      q: "Was macht die Glühbirne mit dem größten Teil ihrer Energie?",
      a: [
        ["A", "Sie wandelt ihn in sichtbares Licht um."],
        ["B", "Sie wandelt ihn überwiegend in Wärme um."],
        ["C", "Die Energie verschwindet im Glühdraht."],
      ],
      c: "B",
      h: [
        "Beide Lampen erhalten elektrische Energie aus der Steckdose.",
        "Energie wird nicht verbraucht, sondern umgewandelt.",
        "Den größten Anteil könnt ihr als starke Hitze spüren.",
      ],
      nd: [
        "Noch nicht.",
        "Ein Hinweis könnte helfen.",
        "Erinnert euch an die fühlbare Wärme der Glühbirne.",
      ],
    },
    res: {
      title: "Die Glühbirne leuchtet – und heizt.",
      p: [
        "Bei einer Glühlampe werden nur etwa <strong>5&nbsp;%</strong> zu Licht – rund <strong>95&nbsp;%</strong> werden zu Wärme.",
        "Eine LED bleibt kühl und macht aus demselben Strom vor allem Licht.",
        "Physikalisch geht nichts verloren: Die 95&nbsp;% Wärme sind im Raum.",
      ],
      terms: [
        [
          "elektrisch",
          "elektrische Energie",
          "Woher erhält eine Lampe ihre elektrische Energie?",
        ],
        [
          "strahlung",
          "Strahlungsenergie",
          "Welche Strahlung der Lampe können wir sehen?",
        ],
        [
          "thermisch",
          "thermische Energie",
          "Wohin wandert die Wärme einer Lampe nach dem Ausschalten?",
        ],
      ],
    },
    trace: {
      lanes: [
        {
          title: "Glühbirne",
          acc: true,
          nodes: [
            ["src", "Stromnetz"],
            ["form", "elektrische Energie"],
            ["sys", "Glühbirne"],
          ],
          outs: [
            ["Licht", "≈ 5 %"],
            ["Wärme", "≈ 95 %"],
          ],
        },
        {
          title: "LED",
          acc: false,
          nodes: [
            ["src", "Stromnetz"],
            ["form", "elektrische Energie"],
            ["sys", "LED"],
          ],
          outs: [
            ["Licht", "größter Teil"],
            ["Wärme", "kleiner Teil"],
          ],
        },
      ],
      concl:
        "Effizienz fragt: Wie viel der zugeführten Energie erreicht die <em>gewünschte Wirkung</em>?",
    },
    done: "Elektrische Energie → Lampe → Licht + Wärme",
  },
  3: {
    n: "03",
    t: "Föhn ↔ Windkraft",
    intro:
      "Zwei Maschinen mit Rotoren. Aber sie laufen in entgegengesetzte Richtungen.",
    steps: [
      [
        "Föhn / Ventilator",
        "Elektrischer Strom treibt einen Motor an, der Luft bewegt.",
      ],
      [
        "Windrad",
        "Bewegte Luft trifft auf Flügel und bringt den Rotor zum Drehen.",
      ],
      ["Vergleichen", "Strom macht Wind ↔ Wind macht Strom."],
    ],
    obs: [
      "Beim Föhn fließt Strom ins Gerät.",
      "Ein Motor dreht das Lüfterrad.",
      "Der Föhn erzeugt bewegte Luft und Wärme.",
      "Beim Windrad bewegt die Luft den Rotor.",
      "Ein Generator wandelt Drehung in Strom um.",
      "Motor und Generator nutzen verwandte Prinzipien.",
    ],
    riddle: {
      q: "Was unterscheidet die beiden Energiespuren grundlegend?",
      a: [
        [
          "A",
          "Beim Föhn führt Strom zu Wind; beim Windrad führt Wind zu Strom.",
        ],
        ["B", "Das Windrad erzeugt Energie neu, der Föhn verbraucht sie."],
        ["C", "Nur der Föhn wandelt Energie um."],
      ],
      c: "A",
      h: [
        "Schaut auf Anfang und Ende der beiden Spuren.",
        "Beim Föhn treibt Strom einen Motor an.",
        "Beim Windrad treibt Wind einen Generator an.",
      ],
      nd: [
        "Noch nicht.",
        "Ein Hinweis könnte helfen.",
        "Wo geht Strom hinein und wo kommt Strom heraus?",
      ],
    },
    res: {
      title: "Motor rückwärts = Generator.",
      p: [
        "Ein <strong>Elektromotor</strong> (Föhn) wandelt Strom in Bewegung um.",
        "Ein <strong>Generator</strong> (Windrad) wandelt Bewegung in Strom um.",
        "Beide Systeme lassen sich als Umkehrung voneinander verstehen.",
      ],
      terms: [
        [
          "rotation",
          "Rotationsenergie",
          "Welche Alltagsgeräte besitzen unsichtbar drehende Rotoren?",
        ],
        [
          "kinetisch",
          "kinetische Energie",
          "Wann besitzt Wind besonders viel Bewegungsenergie?",
        ],
        [
          "elektrisch",
          "elektrische Energie",
          "Wo wird Strom eingespeist und wo entnommen?",
        ],
      ],
    },
    trace: {
      lanes: [
        {
          title: "Föhn (Motor)",
          acc: true,
          nodes: [
            ["src", "Stromnetz"],
            ["form", "elektrische Energie"],
            ["sys", "Föhn (Motor)"],
          ],
          outs: [
            ["Wind", "kinetische Energie"],
            ["Wärme", "Heizung + Reibung"],
          ],
        },
        {
          title: "Windkraft (Generator)",
          acc: false,
          nodes: [
            ["src", "Sonne + Atmosphäre"],
            ["form", "Wind (kinetisch)"],
            ["sys", "Windrad (Generator)"],
          ],
          outs: [
            ["Strom", "elektrische Energie"],
            ["Wärme", "Reibungsverlust"],
          ],
        },
      ],
      concl:
        "Was der Motor antreibt, holt der Generator zurück: Energieumwandlungen sind <em>umkehrbar</em>.",
    },
    done: "Strom → Rotor → Wind ↔ Wind → Rotor → Strom",
  },
  4: {
    n: "04",
    t: "Verbrenner vs. E-Auto",
    intro:
      "Gleicher Auftrag: 1 km fahren. Doch welcher Antrieb bringt mehr Energie an die Räder?",
    obs: [
      "Beide Fahrzeuge brauchen gespeicherte Energie.",
      "Beim Verbrenner wird Kraftstoff verbrannt.",
      "Der Verbrennungsmotor wird sehr heiß.",
      "Auch Akku und Elektromotor erwärmen sich etwas.",
      "Beim E-Auto kommt ein viel größerer Teil als Bewegung an den Rädern an.",
      "Der Akku ist ein Speicher, keine Energiequelle.",
    ],
    riddle: {
      q: "Welches Fahrzeug bringt mehr Energie als Bewegung an die Räder?",
      a: [
        ["A", "Der Verbrenner, weil Verbrennung besonders viel Energie freisetzt."],
        [
          "B",
          "Das E-Auto, weil der Elektromotor einen größeren Anteil in Bewegung umwandelt.",
        ],
        ["C", "Beide gleich viel, wegen der Energieerhaltung."],
      ],
      c: "B",
      h: [
        "Beide Fahrzeuge geben auch Wärme ab.",
        "Im Verbrenner entstehen heiße Gase – nur ein Teil davon bewegt die Kolben.",
        "Der Elektromotor wandelt elektrische Energie direkter in Drehbewegung um.",
      ],
      nd: [
        "Noch nicht.",
        "Ein Hinweis könnte helfen.",
        "Vergleicht den Wärmeanteil der beiden Motoren.",
      ],
    },
    res: {
      title: "Weniger Wärme. Mehr Bewegung.",
      p: [
        "Ein Verbrenner bringt nur etwa <strong>20–30&nbsp;%</strong> der chemischen Energie als Bewegung an die Räder – rund 75&nbsp;% werden zu Wärme.",
        "Beim E-Auto erreichen etwa <strong>70–90&nbsp;%</strong> die Räder als Bewegung.",
        "Wärme ist nicht verloren, aber für das Fahren meist unerwünscht.",
      ],
      terms: [
        [
          "chemisch",
          "chemische Energie",
          "Wo ist die Energie im Kraftstoff und im Akku gespeichert?",
        ],
        [
          "elektrisch",
          "elektrische Energie",
          "Auf welchem Weg fließt Strom vom Akku zum Motor?",
        ],
        [
          "wirkungsgrad",
          "Wirkungsgrad",
          "Welcher Anteil der Energie erfüllt die gewünschte Aufgabe?",
        ],
      ],
    },
    trace: {
      lanes: [
        {
          title: "Verbrenner",
          acc: true,
          nodes: [
            ["src", "Kraftstoff"],
            ["form", "chemische Energie"],
            ["sys", "Verbrennungsmotor"],
          ],
          outs: [
            ["Bewegung", "≈ 25 %"],
            ["Wärme", "≈ 75 %"],
          ],
        },
        {
          title: "E-Auto",
          acc: false,
          nodes: [
            ["src", "geladener Akku"],
            ["form", "elektrische Energie"],
            ["sys", "Elektromotor"],
          ],
          outs: [
            ["Bewegung", "≈ 80 %"],
            ["Wärme", "≈ 20 %"],
          ],
        },
      ],
      concl:
        "Entscheidend ist, welcher Anteil der Energie die gewünschte <em>Bewegung</em> erreicht.",
    },
    done: "Kraftstoff → viel Wärme + Bewegung · Akku → mehr Bewegung",
  },
  5: {
    n: "05",
    t: "Pflanze vs. Tier",
    intro:
      "Beide Lebewesen brauchen Energie. Doch nur die Pflanze kann Sonnenlicht direkt für sich nutzen.",
    obs: [
      "Pflanzen benötigen Licht zum Wachsen.",
      "Pflanzen bauen energiereiche Stoffe selbst auf.",
      "Tiere müssen energiereiche Stoffe über Nahrung aufnehmen.",
      "Die Sonne steht am Anfang beider Spuren.",
      "Der Weg zum Tier führt über zusätzliche Schritte.",
      "Bei Stoffwechselvorgängen entsteht Wärme.",
    ],
    riddle: {
      q: "Wer kann Strahlungsenergie des Sonnenlichts direkt nutzen?",
      a: [
        ["A", "Die grüne Pflanze"],
        ["B", "Das Tier"],
        ["C", "Pflanze und Tier gleichermaßen"],
      ],
      c: "A",
      h: [
        "Tiere können kein Sonnenlicht „essen“.",
        "Pflanzen nehmen kein Futter auf, wachsen aber im Licht.",
        "Bei der Fotosynthese wird Lichtenergie in chemische Energie umgewandelt.",
      ],
      nd: [
        "Noch nicht.",
        "Ein Hinweis könnte helfen.",
        "Wer baut energiereiche Stoffe direkt aus Licht auf?",
      ],
    },
    res: {
      title: "Der direkte Weg beginnt bei der Pflanze.",
      p: [
        "Bei der <strong>Fotosynthese</strong> wandeln grüne Pflanzen Sonnenlicht in chemische Energie um (z.&nbsp;B. Glukose, Stärke).",
        "Tiere können das nicht: Sie müssen energiereiche Stoffe fressen.",
        "Je mehr Schritte eine Kette hat, desto mehr Energie wird als Wärme an die Umgebung abgegeben.",
      ],
      terms: [
        [
          "strahlung",
          "Strahlungsenergie",
          "Welcher Anteil des Sonnenlichts ist für Pflanzen nutzbar?",
        ],
        [
          "fotosynthese",
          "Fotosynthese",
          "Welche Stoffe benötigt die Pflanze dafür?",
        ],
        [
          "chemisch",
          "chemische Energie",
          "In welchen pflanzlichen Teilen wird Energie gespeichert?",
        ],
      ],
    },
    trace: {
      lanes: [
        {
          title: "Pflanze · direkter Weg",
          acc: true,
          nodes: [
            ["src", "Sonne"],
            ["form", "Strahlungsenergie"],
            ["sys", "grüne Pflanze"],
          ],
          outs: [
            ["chemische Energie", "Glukose, Stärke"],
            ["Wärme", "Abgabe an Umgebung"],
          ],
        },
        {
          title: "Tier · indirekter Weg",
          acc: false,
          nodes: [
            ["src", "Sonne"],
            ["sys", "Pflanze"],
            ["form", "Nahrung · chemisch"],
            ["sys", "Tier"],
          ],
          outs: [
            ["Bewegung & Leben", "Lebensvorgänge"],
            ["Wärme", "Stoffwechselwärme"],
          ],
        },
      ],
      concl:
        "Die Pflanze speichert Sonnenlicht direkt. Das Tier nutzt die Energie <em>indirekt über Nahrung</em>.",
    },
    done: "Sonne → Pflanze → Nahrung → Tier → Leben + Wärme",
  },
};

export interface EnergyForm {
  id: string;
  t: string;
  c: string;
  q: string;
}

export const FORMS: EnergyForm[] = [
  {
    id: "chemisch",
    t: "Chemische Energie",
    c: "Cases 01, 04, 05",
    q: "In welchen Speichern steckt sie: Nahrung, Kraftstoff, Akku?",
  },
  {
    id: "elektrisch",
    t: "Elektrische Energie",
    c: "Cases 02, 03, 04",
    q: "Zwischen welchen Systemen wird elektrische Energie transportiert?",
  },
  {
    id: "strahlung",
    t: "Strahlungsenergie",
    c: "Cases 02, 05",
    q: "Wann ist Strahlung der Ausgangspunkt (Sonne) und wann das Ergebnis (Lampe)?",
  },
  {
    id: "kinetisch",
    t: "Kinetische Energie",
    c: "Cases 01, 03, 04, 05",
    q: "Welche Massen bewegen sich: Körper, Luft, Räder?",
  },
  {
    id: "rotation",
    t: "Rotationsenergie",
    c: "Cases 03, 04",
    q: "Wo begegnet euch Drehung als Zwischenschritt zwischen Strom und Bewegung?",
  },
  {
    id: "thermisch",
    t: "Thermische Energie",
    c: "in allen fünf Cases",
    q: "Warum entsteht bei ausnahmslos jeder Umwandlung auch etwas Wärme?",
  },
];
