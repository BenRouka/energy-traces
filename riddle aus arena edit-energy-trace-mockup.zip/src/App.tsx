import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useEffect } from "react";
import { CASES } from "./data";
import { AppProvider, useApp } from "./store";
import {
  CaseAct,
  CaseDone,
  CaseObs,
  CaseRes,
  CaseRiddle,
  CaseStart,
  CaseTrace,
  G01,
  G01r,
  G02,
  G02r,
  G03,
  G03r,
  Home,
  NotFound,
  Summary,
} from "./screens";
import { cn } from "./utils/cn";

/* ============================================================
   ROUTER
============================================================ */

function RoutedScreen({ route }: { route: string }) {
  switch (route) {
    case "home":
      return <Home />;
    case "g01":
      return <G01 />;
    case "g01r":
      return <G01r />;
    case "g02":
      return <G02 />;
    case "g02r":
      return <G02r />;
    case "g03":
      return <G03 />;
    case "g03r":
      return <G03r />;
    case "summary":
      return <Summary />;
    default:
      break;
  }

  const m = route.match(/^c([1-5])-(start|act|obs|rid|res|tra|done)$/);
  if (m) {
    const id = +m[1];
    switch (m[2]) {
      case "start":
        return <CaseStart id={id} />;
      case "act":
        return <CaseAct id={id} />;
      case "obs":
        return <CaseObs id={id} />;
      case "rid":
        return <CaseRiddle id={id} />;
      case "res":
        return <CaseRes id={id} />;
      case "tra":
        return <CaseTrace id={id} />;
      case "done":
        return <CaseDone id={id} />;
    }
  }
  return <NotFound />;
}

/* ============================================================
   MENÜ-DRAWER
============================================================ */

interface MenuEntry {
  no: string;
  label: string;
  route: string;
}

function MenuSection({ title, entries }: { title: string; entries: MenuEntry[] }) {
  const { state, go } = useApp();
  return (
    <div className="mb-7">
      <div className="mb-2.5 px-1 text-[11px] font-bold uppercase tracking-[0.14em] text-acc">
        {title}
      </div>
      <div className="flex flex-col gap-2">
        {entries.map((e) => {
          const current =
            e.route === state.route ||
            (e.route.startsWith("c") &&
              state.route.startsWith(e.route.split("-")[0]));
          return (
            <motion.button
              key={e.route}
              whileTap={{ scale: 0.98 }}
              onClick={() => go(e.route)}
              className={cn(
                "flex min-h-[50px] w-full cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-2.5 text-left transition-colors duration-150",
                current
                  ? "border-acc/40 bg-surface2 text-ink"
                  : "border-line bg-surface text-ink2 hover:border-line2 hover:bg-surface2 hover:text-ink"
              )}
            >
              <span className="min-w-8 text-[13px] font-bold text-acc">
                {e.no}
              </span>
              <span className="text-[15px] font-medium">{e.label}</span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

function MenuDrawer() {
  const { state, setMenu } = useApp();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenu(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setMenu]);

  return (
    <AnimatePresence>
      {state.menuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setMenu(false);
          }}
          className="fixed inset-0 z-50 flex bg-black/65 p-4 backdrop-blur-xl"
          aria-hidden={!state.menuOpen}
        >
          <motion.aside
            initial={{ x: -32, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -24, opacity: 0 }}
            transition={{ type: "spring", stiffness: 380, damping: 34 }}
            className="ct-scroll h-full w-full max-w-[480px] overflow-y-auto rounded-3xl border border-line bg-[#111115] p-6 shadow-2xl"
          >
            <div className="mb-6 flex items-center justify-between">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-acc">
                  ENERGY TRACE
                </div>
                <div className="mt-1 text-[19px] font-bold">Übersicht</div>
              </div>
              <button
                onClick={() => setMenu(false)}
                aria-label="Schließen"
                className="grid h-11 w-11 cursor-pointer place-items-center rounded-full border border-line bg-surface text-ink2 transition-colors hover:bg-surface2 hover:text-ink"
              >
                <X size={17} strokeWidth={2.2} />
              </button>
            </div>

            <MenuSection
              title="Start"
              entries={[{ no: "◆", label: "ENERGY TRACE", route: "home" }]}
            />
            <MenuSection
              title="00 · Was ist Energie?"
              entries={[
                { no: "G01", label: "Die unsichtbare Größe", route: "g01" },
                { no: "G02", label: "Der Verbrauchs-Trick", route: "g02" },
                { no: "G03", label: "Die vielen Gestalten", route: "g03" },
              ]}
            />
            <MenuSection
              title="Cases 01–05"
              entries={[1, 2, 3, 4, 5].map((i) => ({
                no: `0${i}`,
                label: CASES[i].t,
                route: `c${i}-start`,
              }))}
            />
            <MenuSection
              title="Abschluss"
              entries={[
                { no: "Σ", label: "Zusammenfassung", route: "summary" },
              ]}
            />
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ============================================================
   BÜHNE
============================================================ */

function Stage() {
  const { state } = useApp();
  return (
    <div className="relative flex h-full min-h-0 w-full flex-col overflow-hidden rounded-none border-white/[0.06] bg-bg shadow-[0_30px_80px_rgba(0,0,0,0.6)] sm:rounded-3xl sm:border">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{
          background:
            "linear-gradient(to right, transparent, rgba(255,179,64,0.5), transparent)",
        }}
      />
      <AnimatePresence mode="wait">
        <motion.div
          key={state.route}
          initial={{ opacity: 0, y: 22, filter: "blur(5px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -14, filter: "blur(5px)" }}
          transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
          className="flex h-full min-h-0 flex-col"
        >
          <RoutedScreen route={state.route} />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <div className="grid h-dvh place-items-center p-0 sm:p-4 sm:pb-[max(16px,env(safe-area-inset-bottom))]">
        <div className="ambient" />
        <div className="grain" />
        <div className="relative h-full max-h-[920px] w-full max-w-[1200px]">
          <Stage />
        </div>
        <MenuDrawer />
      </div>
    </AppProvider>
  );
}
