import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  type ReactNode,
} from "react";

/* ============================================================
   STATE
============================================================ */

export interface AppState {
  route: string;
  menuOpen: boolean;
  hints: Record<string, number>;
  answers: Record<string, string>;
  wrong: Record<string, number>;
  lastWrong: Record<string, string | null>;
  obs: Record<number, number[]>;
  actIdx: Record<number, number>;
  term: Record<number, string | null>;
  form: string | null;
  customForms: string[];
}

const LS_KEY = "energyTraceCustomForms";

function loadCustomForms(): string[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((v) => typeof v === "string") : [];
  } catch {
    return [];
  }
}

const initialState: AppState = {
  route: "home",
  menuOpen: false,
  hints: {},
  answers: {},
  wrong: {},
  lastWrong: {},
  obs: {},
  actIdx: {},
  term: {},
  form: null,
  customForms: loadCustomForms(),
};

type Action =
  | { type: "nav"; route: string }
  | { type: "menu"; open: boolean }
  | { type: "hint"; key: string; n: number }
  | { type: "correct"; key: string; choice: string }
  | { type: "wrong"; key: string; choice: string }
  | { type: "clear-last-wrong"; key: string }
  | { type: "next-act"; id: number; len: number }
  | { type: "toggle-obs"; id: number; idx: number }
  | { type: "toggle-term"; id: number; tid: string }
  | { type: "toggle-form"; fid: string }
  | { type: "add-custom"; value: string }
  | { type: "remove-custom"; index: number };

function reducer(s: AppState, a: Action): AppState {
  switch (a.type) {
    case "nav":
      return { ...s, route: a.route, menuOpen: false };
    case "menu":
      return { ...s, menuOpen: a.open };
    case "hint":
      return {
        ...s,
        hints: { ...s.hints, [a.key]: Math.max(s.hints[a.key] || 0, a.n) },
      };
    case "correct":
      return { ...s, answers: { ...s.answers, [a.key]: a.choice } };
    case "wrong":
      return {
        ...s,
        wrong: { ...s.wrong, [a.key]: (s.wrong[a.key] || 0) + 1 },
        lastWrong: { ...s.lastWrong, [a.key]: a.choice },
      };
    case "clear-last-wrong": {
      const next = { ...s.lastWrong };
      delete next[a.key];
      return { ...s, lastWrong: next };
    }
    case "next-act":
      return {
        ...s,
        actIdx: { ...s.actIdx, [a.id]: ((s.actIdx[a.id] || 0) + 1) % a.len },
      };
    case "toggle-obs": {
      const cur = s.obs[a.id] || [];
      const next = cur.includes(a.idx)
        ? cur.filter((i) => i !== a.idx)
        : [...cur, a.idx];
      return { ...s, obs: { ...s.obs, [a.id]: next } };
    }
    case "toggle-term":
      return {
        ...s,
        term: { ...s.term, [a.id]: s.term[a.id] === a.tid ? null : a.tid },
      };
    case "toggle-form":
      return { ...s, form: s.form === a.fid ? null : a.fid };
    case "add-custom":
      return { ...s, customForms: [...s.customForms, a.value] };
    case "remove-custom":
      return {
        ...s,
        customForms: s.customForms.filter((_, i) => i !== a.index),
      };
    default:
      return s;
  }
}

/* ============================================================
   CONTEXT
============================================================ */

interface AppApi {
  state: AppState;
  go: (route: string) => void;
  setMenu: (open: boolean) => void;
  openHint: (key: string, n: number) => void;
  choose: (
    key: string,
    choice: string,
    correct: string,
    next: string,
    mode?: string
  ) => void;
  nextAct: (id: number, len: number) => void;
  toggleObs: (id: number, idx: number) => void;
  toggleTerm: (id: number, tid: string) => void;
  toggleForm: (fid: string) => void;
  addCustom: (value: string) => boolean;
  removeCustom: (index: number) => void;
}

const AppCtx = createContext<AppApi | null>(null);

export function useApp(): AppApi {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp muss innerhalb von AppProvider liegen");
  return ctx;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const stateRef = useRef(state);
  const timers = useRef<Record<string, number>>({});

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state.customForms));
    } catch {
      /* ignorieren */
    }
  }, [state.customForms]);

  const go = useCallback((route: string) => dispatch({ type: "nav", route }), []);
  const setMenu = useCallback(
    (open: boolean) => dispatch({ type: "menu", open }),
    []
  );
  const openHint = useCallback(
    (key: string, n: number) => dispatch({ type: "hint", key, n }),
    []
  );

  const choose = useCallback(
    (key: string, choice: string, correct: string, next: string, mode?: string) => {
      if (stateRef.current.answers[key]) return;

      if (mode === "any" || choice === correct) {
        dispatch({ type: "correct", key, choice });
        window.setTimeout(() => dispatch({ type: "nav", route: next }), 620);
      } else {
        dispatch({ type: "wrong", key, choice });
        if (timers.current[key]) window.clearTimeout(timers.current[key]);
        timers.current[key] = window.setTimeout(
          () => dispatch({ type: "clear-last-wrong", key }),
          560
        );
      }
    },
    []
  );

  const nextAct = useCallback(
    (id: number, len: number) => dispatch({ type: "next-act", id, len }),
    []
  );
  const toggleObs = useCallback(
    (id: number, idx: number) => dispatch({ type: "toggle-obs", id, idx }),
    []
  );
  const toggleTerm = useCallback(
    (id: number, tid: string) => dispatch({ type: "toggle-term", id, tid }),
    []
  );
  const toggleForm = useCallback(
    (fid: string) => dispatch({ type: "toggle-form", fid }),
    []
  );

  const addCustom = useCallback((value: string): boolean => {
    const v = value.trim();
    if (!v) return false;
    const exists = stateRef.current.customForms.some(
      (item) => item.toLocaleLowerCase("de") === v.toLocaleLowerCase("de")
    );
    if (exists) return false;
    dispatch({ type: "add-custom", value: v });
    return true;
  }, []);

  const removeCustom = useCallback(
    (index: number) => dispatch({ type: "remove-custom", index }),
    []
  );

  const api = useMemo<AppApi>(
    () => ({
      state,
      go,
      setMenu,
      openHint,
      choose,
      nextAct,
      toggleObs,
      toggleTerm,
      toggleForm,
      addCustom,
      removeCustom,
    }),
    [state, go, setMenu, openHint, choose, nextAct, toggleObs, toggleTerm, toggleForm, addCustom, removeCustom]
  );

  return <AppCtx.Provider value={api}>{children}</AppCtx.Provider>;
}
