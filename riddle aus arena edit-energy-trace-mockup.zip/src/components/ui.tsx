import { AnimatePresence, motion } from "framer-motion";
import { Lock, Menu, Check, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { useApp } from "../store";
import type { Lane, TraceNodeType } from "../data";
import { cn } from "../utils/cn";

/* ============================================================
   MICRO-LABEL & GLYPHEN
============================================================ */

export function Micro({
  children,
  accent = false,
  className,
}: {
  children: ReactNode;
  accent?: boolean;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "text-[11px] font-semibold uppercase tracking-[0.14em] leading-4",
        accent ? "text-acc" : "text-ink3",
        className
      )}
    >
      {children}
    </div>
  );
}

const SYM: Record<TraceNodeType | "diamond", { ch: string; cls: string }> = {
  src: { ch: "◆", cls: "text-acc" },
  form: { ch: "●", cls: "text-ink" },
  sys: { ch: "○", cls: "hollow" },
  diamond: { ch: "◆", cls: "text-acc" },
};

export function Sym({
  kind,
  size = 18,
  className,
}: {
  kind: TraceNodeType | "diamond";
  size?: number;
  className?: string;
}) {
  const s = SYM[kind];
  return (
    <span
      aria-hidden
      className={cn("glyph inline-block", s.cls, className)}
      style={{ fontSize: size }}
    >
      {s.ch}
    </span>
  );
}

export function HeroGlyph() {
  return (
    <div className="relative grid h-24 w-24 place-items-center">
      <div className="absolute h-32 w-32 rounded-full bg-acc/10 blur-2xl" />
      <div className="absolute inset-0 rounded-full border border-acc/25" />
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background:
            "conic-gradient(from 0deg, transparent 70%, rgba(255,179,64,0.7), transparent 100%)",
          mask: "radial-gradient(farthest-side, transparent calc(100% - 1.5px), black calc(100% - 1.5px))",
          WebkitMask:
            "radial-gradient(farthest-side, transparent calc(100% - 1.5px), black calc(100% - 1.5px))",
          animation: "orbit-rotate 7s linear infinite",
        }}
      />
      <span className="glyph breathe text-acc" style={{ fontSize: 38 }}>
        ◆
      </span>
    </div>
  );
}

/* ============================================================
   BUTTONS
============================================================ */

export function Btn({
  variant = "primary",
  onClick,
  children,
  icon: Icon,
  iconRight = false,
  className,
}: {
  variant?: "primary" | "secondary";
  onClick: () => void;
  children: ReactNode;
  icon?: LucideIcon;
  iconRight?: boolean;
  className?: string;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      onClick={onClick}
      className={cn(
        "group inline-flex min-h-12 cursor-pointer items-center justify-center gap-2.5 rounded-full px-6 text-[15px] font-semibold whitespace-nowrap transition-colors duration-200 select-none",
        variant === "primary"
          ? "bg-ink text-[#0A0A0C] hover:bg-white"
          : "border border-line bg-surface text-ink hover:bg-surface2",
        className
      )}
    >
      {Icon && !iconRight && (
        <Icon size={16} strokeWidth={2.4} className="shrink-0" />
      )}
      <span>{children}</span>
      {Icon && iconRight && (
        <Icon
          size={16}
          strokeWidth={2.4}
          className="shrink-0 transition-transform duration-200 group-hover:translate-x-0.5"
        />
      )}
    </motion.button>
  );
}

/* ============================================================
   LERNKARTE / INFO
============================================================ */

export function Learn({
  k,
  children,
  className,
}: {
  k: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-r-2xl border border-acc/40 border-l-4 border-l-acc bg-surface px-6 py-5",
        className
      )}
    >
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(110deg, rgba(255,179,64,0.13), transparent 68%)",
        }}
      />
      <div className="relative">
        <div className="mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-acc">
          {k}
        </div>
        <div className="rich text-[19px] font-semibold leading-7 text-ink">
          {children}
        </div>
      </div>
    </div>
  );
}

export function InfoBox({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-line bg-surface px-5 py-4 text-[15px] leading-6 text-ink2">
      <span className="glyph mt-1 text-acc" style={{ fontSize: 13 }}>
        ◆
      </span>
      <div className="rich">{children}</div>
    </div>
  );
}

/* ============================================================
   RAHMEN: HEADER · CONTENT · FOOTER
============================================================ */

function Dots({ cn: caseNum }: { cn: number }) {
  return (
    <div className="flex items-center gap-2.5" aria-label={`Case ${caseNum} von 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <span
          key={n}
          className={cn(
            "h-[9px] w-[9px] rounded-full border-[1.5px] transition-all duration-300",
            n <= caseNum ? "border-acc bg-acc" : "border-ink3 bg-transparent",
            n === caseNum && "pulse-dot"
          )}
        />
      ))}
    </div>
  );
}

export function Screen({
  label,
  cn: caseNum = null,
  footer,
  children,
}: {
  label: string;
  cn?: number | null;
  footer?: ReactNode;
  children: ReactNode;
}) {
  const { setMenu } = useApp();
  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex min-h-16 shrink-0 items-center justify-between gap-4 px-5 pt-4 pb-2 sm:px-8">
        <div className="flex min-w-0 items-center gap-3">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setMenu(true)}
            aria-label="Menü öffnen"
            className="grid h-11 w-11 shrink-0 cursor-pointer place-items-center rounded-full border border-line bg-surface text-ink2 transition-colors hover:bg-surface2 hover:text-ink"
          >
            <Menu size={17} strokeWidth={2.2} />
          </motion.button>
          <div className="truncate text-[11px] font-semibold uppercase tracking-[0.14em] text-ink3">
            {label}
          </div>
        </div>
        {caseNum ? <Dots cn={caseNum} /> : null}
      </header>

      <main className="ct-scroll min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pt-2 pb-6 sm:px-8">
        <div className="mx-auto min-h-full w-full max-w-[1040px]">{children}</div>
      </main>

      <footer
        className="relative z-10 flex min-h-[74px] shrink-0 items-center px-5 pt-3 pb-[max(16px,env(safe-area-inset-bottom))] sm:px-8"
        style={{
          background: "linear-gradient(to top, var(--color-bg) 72%, transparent)",
        }}
      >
        <div className="mx-auto flex w-full max-w-[1040px] items-center gap-3">
          {footer}
        </div>
      </footer>
    </div>
  );
}

export function FootSpacer() {
  return <span className="flex-1" />;
}

/* ============================================================
   HINWEISE (Chips, progressiv, sperren Antworten)
============================================================ */

export function Hints({ hintKey, hints }: { hintKey: string; hints: string[] }) {
  const { state, openHint } = useApp();
  const op = state.hints[hintKey] || 0;

  return (
    <div className="flex flex-col gap-3.5">
      <Micro>
        Hinweise ({op} von {hints.length} geöffnet)
      </Micro>
      <div className="flex flex-wrap gap-2.5">
        {hints.map((_, i) => {
          const n = i + 1;
          const isOpen = n <= op;
          const isLocked = n > op + 1;
          const isNext = n === op + 1;
          return (
            <motion.button
              key={n}
              whileTap={!isLocked ? { scale: 0.95 } : undefined}
              onClick={() => !isLocked && openHint(hintKey, n)}
              disabled={isLocked}
              className={cn(
                "inline-flex min-h-11 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition-all duration-200",
                isOpen
                  ? "border-acc/50 text-ink"
                  : isNext
                    ? "cursor-pointer border-line bg-surface text-ink2 hover:border-acc/40 hover:text-ink"
                    : "cursor-not-allowed border-line/60 bg-surface text-ink2 opacity-40"
              )}
            >
              Hinweis {n}
              {isLocked && <Lock size={12} strokeWidth={2.4} />}
              {isNext && (
                <span className="h-1.5 w-1.5 rounded-full bg-acc pulse-dot" />
              )}
            </motion.button>
          );
        })}
      </div>
      <div className="flex flex-col gap-2.5">
        <AnimatePresence initial={false}>
          {hints.slice(0, op).map((h, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: "spring", stiffness: 320, damping: 28 }}
              className="rounded-xl border border-line border-l-[3px] border-l-acc bg-surface px-5 py-4"
            >
              <Micro accent className="mb-1.5">
                Hinweis {i + 1}
              </Micro>
              <div className="text-[15px] leading-6 text-ink">{h}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ============================================================
   ANTWORTKARTEN
============================================================ */

export function Answers({
  aKey,
  answers,
  correct,
  next,
  mode = "normal",
}: {
  aKey: string;
  answers: [string, string][];
  correct: string;
  next: string;
  mode?: string;
}) {
  const { state, choose } = useApp();
  const sel = state.answers[aKey];
  const lw = state.lastWrong[aKey];
  const opened = state.hints[aKey] || 0;
  const unlocked = opened >= 3;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-3">
        {answers.map(([id, txt], i) => {
          const isSel = sel === id;
          const isW = lw === id;
          const dim = sel && sel !== id;
          return (
            <motion.button
              key={id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: dim ? 0.32 : 1, y: 0 }}
              transition={{ delay: i * 0.06, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              onClick={() => choose(aKey, id, correct, next, mode)}
              disabled={!unlocked || !!sel}
              aria-disabled={!unlocked || !!sel}
              className={cn(
                "flex min-h-16 w-full items-center gap-4 rounded-2xl border-[1.5px] border-line bg-surface px-5 py-3 text-left transition-all duration-200",
                isW && "shake border-err",
                isSel &&
                  "border-acc shadow-[0_0_36px_rgba(255,179,64,0.14)] [background:linear-gradient(0deg,rgba(255,179,64,0.13),rgba(255,179,64,0.13)),#141419]",
                !isSel && !isW && unlocked && !sel
                  ? "cursor-pointer hover:border-line2 hover:bg-surface2"
                  : !unlocked && "opacity-45"
              )}
            >
              <span
                className={cn(
                  "grid h-9 w-9 shrink-0 place-items-center rounded-[10px] bg-surface2 text-[15px] font-bold text-ink2 transition-colors duration-200",
                  isSel && "bg-acc text-[#0A0A0C]",
                  isW && "text-err bg-err/10"
                )}
              >
                {isW ? "×" : id}
              </span>
              <span className="text-[16.5px] font-medium leading-6 text-ink">
                {txt}
              </span>
            </motion.button>
          );
        })}
      </div>

      {!unlocked && (
        <div className="mt-1 flex items-center gap-2.5 text-[13px] leading-5 text-ink3" aria-live="polite">
          <Lock size={13} strokeWidth={2.2} className="shrink-0" />
          <span>Öffnet alle drei Hinweise, um die Antworten freizuschalten.</span>
        </div>
      )}
    </div>
  );
}

export function Feedback({ children }: { children?: ReactNode }) {
  return (
    <div className="min-h-5 text-center text-sm text-ink2">
      <AnimatePresence mode="wait">
        {children ? (
          <motion.span
            key={String(children)}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="inline-block"
          >
            {children}
          </motion.span>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

/* ============================================================
   TRACE-DIAGRAMM
============================================================ */

export function TraceView({ lanes }: { lanes: Lane[] }) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap justify-center gap-x-6 gap-y-2">
        <div className="flex items-center gap-2 text-xs text-ink2">
          <Sym kind="src" size={15} />
          <span>Quelle</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-ink2">
          <Sym kind="form" size={15} />
          <span>Energieform / Wirkung</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-ink2">
          <Sym kind="sys" size={15} />
          <span>System</span>
        </div>
      </div>

      <div
        className={cn(
          "grid grid-cols-1 gap-4",
          lanes.length > 1 && "lg:grid-cols-2"
        )}
      >
        {lanes.map((l, li) => (
          <motion.div
            key={li}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: li * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className={cn(
              "rounded-3xl border border-line bg-surface p-5",
              l.acc ? "border-t-[3px] border-t-acc" : "border-t-[3px] border-t-ink/80"
            )}
          >
            <div className="mb-4 text-[17px] font-bold leading-6 text-ink">
              {l.title}
            </div>
            <div className="flex flex-col items-stretch">
              {l.nodes.map(([t, name], ni) => (
                <div key={ni} className="contents">
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 + li * 0.1 + ni * 0.08 }}
                    className="flex min-h-11 items-center justify-center gap-2.5 rounded-xl border border-line bg-white/[0.03] px-3 py-2 text-center text-sm font-semibold text-ink"
                  >
                    <Sym kind={t} size={t === "sys" ? 16 : 14} />
                    <span>{name}</span>
                  </motion.div>
                  <div className="tconn" />
                </div>
              ))}
              <div className="mt-1 grid grid-cols-2 gap-2">
                {l.outs.map(([name, sub], oi) => (
                  <motion.div
                    key={oi}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      delay: 0.2 + li * 0.1 + l.nodes.length * 0.08 + oi * 0.07,
                    }}
                    className="flex min-h-[74px] flex-col items-center justify-center gap-1 rounded-xl border border-line bg-white/[0.03] p-2.5 text-center text-[13px]"
                  >
                    <Sym kind="form" size={13} />
                    <strong className="font-semibold text-ink">{name}</strong>
                    <span className="text-ink3">{sub}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export function CoreConclusion({ html }: { html: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.35, duration: 0.5 }}
      className="core rounded-r-xl border-l-[3px] border-l-acc px-6 py-5 text-[17px] font-semibold leading-7 text-ink"
      style={{
        background:
          "linear-gradient(100deg, rgba(255,179,64,0.13), transparent 70%)",
      }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export function ObsCheck({ selected }: { selected: boolean }) {
  return (
    <span
      className={cn(
        "grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full border-[1.5px] transition-all duration-200",
        selected ? "border-acc bg-acc text-[#0A0A0C]" : "border-ink3 text-transparent"
      )}
    >
      <Check size={12} strokeWidth={3.2} />
    </span>
  );
}
