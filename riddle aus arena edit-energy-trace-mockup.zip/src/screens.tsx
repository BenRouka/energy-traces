import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Plus, RotateCw, X } from "lucide-react";
import {
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { CASES, FORMS } from "./data";
import { useApp } from "./store";
import {
  Answers,
  Btn,
  CoreConclusion,
  Feedback,
  FootSpacer,
  HeroGlyph,
  Hints,
  InfoBox,
  Learn,
  Micro,
  ObsCheck,
  Screen,
  Sym,
  TraceView,
} from "./components/ui";
import { cn } from "./utils/cn";

/* ---------- Gemeinsame Bausteine ---------- */

const stack = "flex flex-col gap-6 py-3 pb-9";
const hero =
  "flex min-h-full flex-col items-center justify-center gap-6 py-6 text-center";

const displayStyle = { fontSize: "clamp(32px, 4.6vw, 52px)" };
const titleStyle = { fontSize: "clamp(24px, 3vw, 34px)" };

function Display({
  children,
  style = displayStyle,
  className,
}: {
  children: ReactNode;
  style?: CSSProperties;
  className?: string;
}) {
  return (
    <h1
      style={style}
      className={cn("font-bold leading-[1.06] tracking-[-0.025em] text-balance", className)}
    >
      {children}
    </h1>
  );
}

function BodyL({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p className={cn("text-[17px] leading-7 text-ink2 sm:text-lg", className)}>
      {children}
    </p>
  );
}

function RichBodyL({ html }: { html: string }) {
  return (
    <p
      className="rich text-[17px] leading-[1.75] text-ink2 sm:text-lg"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}



/* ============================================================
   00 · HOME & GRUNDLAGEN
============================================================ */

export function Home() {
  const { go } = useApp();
  return (
    <Screen
      label="ENERGY TRACE"
      footer={
        <>
          <FootSpacer />
          <Btn onClick={() => go("g01")} icon={ArrowRight} iconRight>
            Starten
          </Btn>
        </>
      }
    >
      <div className={hero}>
        <HeroGlyph />
        <div className="flex flex-col items-center gap-3">
          <Micro accent>Interaktives Entdeckerrätsel</Micro>
          <Display>
            Was ist <span className="serif-acc text-acc">Energie</span>?
          </Display>
          <BodyL className="max-w-[560px]">
            Finde heraus, was hinter dem Begriff steckt – erst in drei
            Grundlagenrätseln, dann in fünf Spuren des Alltags.
          </BodyL>
        </div>
      </div>
    </Screen>
  );
}

export function G01() {
  const { state, go } = useApp();
  const hints = [
    "Man kann mich nicht sehen, hören, schmecken oder riechen.",
    "Man spricht davon, dass ich „verbraucht“ werde. Aber ich verschwinde dabei nicht.",
    "Du erkennst mich daran, was ich bewirken kann.",
  ];
  return (
    <Screen
      label="00 · G01 · Rätsel"
      footer={
        <Btn variant="secondary" onClick={() => go("home")} icon={ArrowLeft}>
          Start
        </Btn>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Rätsel 01</Micro>
          <Display className="mt-2">Was bin ich?</Display>
        </div>
        <Hints hintKey="g01" hints={hints} />
        <Answers
          aKey="g01"
          answers={[
            ["A", "Energie"],
            ["B", "Kraft"],
            ["C", "Stoff"],
          ]}
          correct="A"
          next="g01r"
        />
        <Feedback>
          {state.wrong["g01"] ? "Noch nicht. Schau dir die Hinweise an!" : null}
        </Feedback>
      </div>
    </Screen>
  );
}

export function G01r() {
  const { go } = useApp();
  return (
    <Screen
      label="00 · G01 · Auflösung"
      footer={
        <>
          <Btn variant="secondary" onClick={() => go("g01")} icon={ArrowLeft}>
            Zurück
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go("g02")} icon={ArrowRight} iconRight>
            Weiter zu Rätsel 02
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Genau.</Micro>
          <Display className="mt-2">
            <span className="serif-acc text-acc">Energie.</span>
          </Display>
        </div>
        <BodyL>
          Du kannst mich nicht direkt beobachten.
          <br />
          Du kannst beobachten, was durch mich möglich wird.
        </BodyL>
        <Learn k="Erste Lernkarte">
          Energie beschreibt die Möglichkeit, Veränderungen zu bewirken.
        </Learn>
      </div>
    </Screen>
  );
}

export function G02() {
  const { state, go } = useApp();
  const hints = [
    "Den Begriff hast du bestimmt schon oft gehört.",
    "Es klingt so, als wäre danach weniger da – oder gar nichts mehr.",
    "Schau auf das, was nachher da ist: Licht, Wärme, Bewegung.",
  ];
  return (
    <Screen
      label="00 · G02 · Rätsel"
      footer={
        <Btn variant="secondary" onClick={() => go("g01r")} icon={ArrowLeft}>
          Zurück
        </Btn>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Rätsel 02</Micro>
          <Display className="mt-2">Was wird eigentlich verbraucht?</Display>
        </div>
        <Hints hintKey="g02" hints={hints} />
        <Answers
          aKey="g02"
          answers={[
            ["A", "Energie verschwindet"],
            ["B", "Energie wird umgewandelt"],
          ]}
          correct="B"
          next="g02r"
        />
        <Feedback>
          {state.wrong["g02"] ? "Überlege: Was entsteht danach?" : null}
        </Feedback>
      </div>
    </Screen>
  );
}

export function G02r() {
  const { go } = useApp();
  return (
    <Screen
      label="00 · G02 · Auflösung"
      footer={
        <>
          <Btn variant="secondary" onClick={() => go("g02")} icon={ArrowLeft}>
            Zur Frage
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go("g03")} icon={ArrowRight} iconRight>
            Weiter zu Rätsel 03
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Auflösung</Micro>
          <Display className="mt-2">
            Energie<span className="serif-acc text-acc">verbrauch</span>
          </Display>
          <div className="mt-3 text-[22px] font-bold tracking-[-0.01em]">
            Die Energie verschwindet nicht.
          </div>
        </div>

        <div className="mx-auto flex w-full max-w-[480px] flex-col items-stretch gap-1.5">
          {[
            { t: "zugeführte Energie", hot: false },
            { t: "Umwandlung", hot: true },
            { t: "andere Energieformen", hot: false },
          ].map((box, i) => (
            <div key={i} className="contents">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.18 }}
                className={cn(
                  "rounded-xl border px-4 py-4 text-center text-[16px] font-semibold",
                  box.hot
                    ? "border-acc/50 text-ink [background:linear-gradient(0deg,rgba(255,179,64,0.13),rgba(255,179,64,0.13)),#141419]"
                    : "border-line bg-surface"
                )}
              >
                {box.t}
              </motion.div>
              {i < 2 && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.18 + 0.12 }}
                  className="glyph py-0.5 text-center text-acc"
                  style={{ fontSize: 18 }}
                >
                  ↓
                </motion.span>
              )}
            </div>
          ))}
        </div>

        <Learn k="Zweite Lernkarte">
          „Verbraucht“ ist praktisch. Physikalisch ist „umgewandelt und
          übertragen“ genauer.
        </Learn>
      </div>
    </Screen>
  );
}

export function G03() {
  const { go } = useApp();
  const hints = [
    "In Schulbüchern stehen oft Listen.",
    "Manche zählen 8, manche 10, manche noch mehr.",
    "Vielleicht ist die Zahl selbst die falsche Fährte.",
  ];
  return (
    <Screen
      label="00 · G03 · Rätsel"
      footer={
        <Btn variant="secondary" onClick={() => go("g02r")} icon={ArrowLeft}>
          Zurück
        </Btn>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Rätsel 03</Micro>
          <Display className="mt-2">
            Wie viele Formen kann Energie annehmen?
          </Display>
        </div>
        <Hints hintKey="g03" hints={hints} />
        <Answers
          aKey="g03"
          answers={[
            ["A", "8"],
            ["B", "20"],
            ["C", "100"],
          ]}
          correct=""
          next="g03r"
          mode="any"
        />
        <Micro className="text-center normal-case tracking-normal">
          Tippe auf die Zahl, die du vermutest.
        </Micro>
      </div>
    </Screen>
  );
}

export function G03r() {
  const { go } = useApp();
  return (
    <Screen
      label="00 · G03 · Auflösung"
      footer={
        <>
          <Btn variant="secondary" onClick={() => go("g03")} icon={ArrowLeft}>
            Zurück
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go("c1-start")} icon={ArrowRight} iconRight>
            Weiter zu Case 01: Bewegungsspiel
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Entdecker-Moment</Micro>
          <Display className="mt-2">
            Keine dieser Zahlen ist{" "}
            <span className="serif-acc text-acc">richtig.</span>
          </Display>
        </div>
        <BodyL className="rich">
          Es gibt keine kleine, feste Liste, die man einfach auswendig lernen
          muss. Energieformen sind <em>Beschreibungen</em> dafür, wie Energie in
          einer Situation auftritt.
        </BodyL>
        <Learn k="Dritte Lernkarte">
          Beschreibe, in welcher Form die Energie auftritt — und wie sie
          umgewandelt wird.
        </Learn>
        <InfoBox>
          In den folgenden fünf Cases verfolgen wir ganz konkrete Energiespuren.
          Los geht es mit dem eigenen Körper.
        </InfoBox>
      </div>
    </Screen>
  );
}

/* ============================================================
   CASES 01–05
============================================================ */

export function CaseStart({ id }: { id: number }) {
  const { go } = useApp();
  const c = CASES[id];
  return (
    <Screen
      label={`Case ${c.n} · ${c.t}`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(id === 1 ? "g03r" : `c${id - 1}-done`)}
            icon={ArrowLeft}
          >
            Zurück
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(`c${id}-act`)} icon={ArrowRight} iconRight>
            Aktivität starten
          </Btn>
        </>
      }
    >
      <div className={hero}>
        <HeroGlyph />
        <div className="flex flex-col items-center gap-3">
          <Micro accent>Case {c.n}</Micro>
          <Display>{c.t}</Display>
          <BodyL className="max-w-[580px]">{c.intro}</BodyL>
        </div>
      </div>
    </Screen>
  );
}

function ActCycleCard({
  caseId,
  kicker,
  word,
  desc,
}: {
  caseId: number;
  kicker: string;
  word: string;
  desc: string;
}) {
  const { state, nextAct } = useApp();
  const items = caseId === 1 ? CASES[1].impulses! : CASES[caseId].steps!;
  return (
    <motion.button
      whileTap={{ scale: 0.985 }}
      onClick={() => nextAct(caseId, items.length)}
      className="group flex min-h-[260px] w-full cursor-pointer flex-col items-center justify-center gap-5 rounded-3xl border border-line bg-surface px-7 py-8 text-center transition-colors duration-200 hover:border-acc/40"
    >
      <div className="flex items-center gap-2 text-acc">
        <RotateCw
          size={12}
          strokeWidth={2.4}
          className="transition-transform duration-300 group-hover:rotate-45"
        />
        <span className="text-[11px] font-semibold uppercase tracking-[0.14em]">
          {kicker}
        </span>
      </div>
      <div className="relative grid min-h-[72px] w-full place-items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={word}
            initial={{ opacity: 0, y: 16, filter: "blur(6px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -12, filter: "blur(6px)" }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            className="text-[clamp(32px,4.8vw,54px)] font-bold leading-[1.08] tracking-[-0.02em]"
          >
            {word}
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="max-w-[620px] text-[16px] leading-6.5 text-ink2">
        {desc}
      </div>
      <div className="flex gap-1.5">
        {items.map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-1 rounded-full transition-all duration-300",
              i === (state.actIdx[caseId] || 0)
                ? "w-5 bg-acc"
                : "w-1.5 bg-ink3/50"
            )}
          />
        ))}
      </div>
    </motion.button>
  );
}

function Bar({ white, amber }: { white: number; amber: number }) {
  return (
    <div className="mt-4">
      <div className="flex h-3.5 overflow-hidden rounded-lg bg-surface2">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${white}%` }}
          transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="bg-ink"
        />
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${amber}%` }}
          transition={{ delay: 0.35, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="bg-acc"
        />
      </div>
      <div className="mt-2 flex justify-between gap-2 text-[13px] text-ink2">
        <span>Bewegung ≈ {white}&nbsp;%</span>
        <span>Wärme ≈ {amber}&nbsp;%</span>
      </div>
    </div>
  );
}

export function CaseAct({ id }: { id: number }) {
  const { state, go } = useApp();
  const c = CASES[id];

  let body: ReactNode = null;

  if (id === 1) {
    const idx = state.actIdx[1] || 0;
    const item = c.impulses![idx];
    body = (
      <ActCycleCard
        caseId={1}
        kicker={`Impuls ${idx + 1} von ${c.impulses!.length} · Tippen für nächsten Impuls`}
        word={item[0]}
        desc={item[1]}
      />
    );
  } else if (id === 2 || id === 3) {
    const idx = state.actIdx[id] || 0;
    const item = c.steps![idx];
    body = (
      <ActCycleCard
        caseId={id}
        kicker={`Schritt ${idx + 1} von ${c.steps!.length} · Tippen für nächsten Schritt`}
        word={item[0]}
        desc={item[1]}
      />
    );
  } else if (id === 4) {
    body = (
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-3xl border border-line border-t-[3px] border-t-acc bg-surface p-6">
          <div className="text-[19px] font-bold">Verbrenner</div>
          <div className="mt-1.5 text-[15px] text-ink2">
            Kraftstoff → Verbrennung → Räder
          </div>
          <Bar white={25} amber={75} />
        </div>
        <div className="rounded-3xl border border-line border-t-[3px] border-t-ink/80 bg-surface p-6">
          <div className="text-[19px] font-bold">E-Auto</div>
          <div className="mt-1.5 text-[15px] text-ink2">
            Akku → Elektromotor → Räder
          </div>
          <Bar white={80} amber={20} />
        </div>
      </div>
    );
  } else if (id === 5) {
    body = (
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-3xl border border-line border-t-[3px] border-t-acc bg-surface p-6">
          <div className="text-[19px] font-bold">Pflanze (Erzeuger)</div>
          <p className="rich mt-2.5 text-[15px] leading-6.5 text-ink2">
            Nimmt Sonnenlicht auf und speichert die Energie durch{" "}
            <strong>Fotosynthese</strong> in energiereichen Stoffen.
          </p>
        </div>
        <div className="rounded-3xl border border-line border-t-[3px] border-t-ink/80 bg-surface p-6">
          <div className="text-[19px] font-bold">Tier (Verbraucher)</div>
          <p className="rich mt-2.5 text-[15px] leading-6.5 text-ink2">
            Kann kein Sonnenlicht direkt nutzen. Muss energiereiche Stoffe über
            die <strong>Nahrung</strong> aufnehmen.
          </p>
        </div>
      </div>
    );
  }

  const info =
    id === 1
      ? "Macht kurz mit! Spürt euren Puls, euren Atem und die Wärme eures Körpers."
      : id === 4
        ? "Beide Fahrzeuge nutzen gespeicherte Energie. Doch das E-Auto bringt deutlich mehr davon als Bewegung an die Räder."
        : id === 5
          ? "Die Sonne steht am Anfang beider Wege. Doch der Weg zum Tier hat Zwischenschritte."
          : null;

  return (
    <Screen
      label={`Case ${c.n} · Aktivität`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(`c${id}-start`)}
            icon={ArrowLeft}
          >
            Start
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(`c${id}-obs`)} icon={ArrowRight} iconRight>
            Weiter zur Beobachtung
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Case {c.n} · Einstieg</Micro>
          <Display style={titleStyle} className="mt-2">
            Ausprobieren & Beobachten
          </Display>
        </div>
        {body}
        {info && <InfoBox>{info}</InfoBox>}
      </div>
    </Screen>
  );
}

export function CaseObs({ id }: { id: number }) {
  const { state, go, toggleObs } = useApp();
  const c = CASES[id];
  const sel = state.obs[id] || [];
  return (
    <Screen
      label={`Case ${c.n} · Beobachtung`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(`c${id}-act`)}
            icon={ArrowLeft}
          >
            Aktivität
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(`c${id}-rid`)} icon={ArrowRight} iconRight>
            Weiter zum Rätsel
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Beobachtung</Micro>
          <Display style={titleStyle} className="mt-2">
            Was habt ihr bemerkt?
          </Display>
        </div>
        <div className="flex flex-col gap-1 rounded-3xl border border-line bg-surface p-3">
          {c.obs.map((txt, i) => {
            const isSel = sel.includes(i);
            return (
              <motion.button
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04, duration: 0.35 }}
                whileTap={{ scale: 0.985 }}
                onClick={() => toggleObs(id, i)}
                className={cn(
                  "flex min-h-[52px] w-full cursor-pointer items-center gap-3.5 rounded-xl px-3.5 py-2 text-left transition-colors duration-150 hover:bg-surface2",
                  isSel ? "text-ink" : "text-ink2"
                )}
              >
                <ObsCheck selected={isSel} />
                <span className="text-[15px] leading-6">{txt}</span>
              </motion.button>
            );
          })}
        </div>
        <Micro className="text-center normal-case tracking-normal">
          Wählt alle Punkte an, die zutreffen. ({sel.length} von {c.obs.length})
        </Micro>
      </div>
    </Screen>
  );
}

export function CaseRiddle({ id }: { id: number }) {
  const { state, go } = useApp();
  const c = CASES[id];
  const key = `c${id}`;
  const wrongCount = state.wrong[key] || 0;
  return (
    <Screen
      label={`Case ${c.n} · Rätsel`}
      cn={id}
      footer={
        <Btn
          variant="secondary"
          onClick={() => go(`c${id}-obs`)}
          icon={ArrowLeft}
        >
          Beobachtung
        </Btn>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Rätsel</Micro>
          <Display style={titleStyle} className="mt-2">
            {c.riddle.q}
          </Display>
        </div>
        <Hints hintKey={key} hints={c.riddle.h} />
        <Answers
          aKey={key}
          answers={c.riddle.a}
          correct={c.riddle.c}
          next={`c${id}-res`}
        />
        <Feedback>
          {wrongCount
            ? c.riddle.nd[Math.min(wrongCount - 1, c.riddle.nd.length - 1)]
            : null}
        </Feedback>
      </div>
    </Screen>
  );
}

export function CaseRes({ id }: { id: number }) {
  const { state, go, toggleTerm } = useApp();
  const c = CASES[id];
  const openT = state.term[id];
  return (
    <Screen
      label={`Case ${c.n} · Auflösung`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(`c${id}-rid`)}
            icon={ArrowLeft}
          >
            Zum Rätsel
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(`c${id}-tra`)} icon={ArrowRight} iconRight>
            Energiespur ansehen
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <div>
          <Micro accent>Auflösung</Micro>
          <Display style={titleStyle} className="mt-2">
            {c.res.title}
          </Display>
        </div>
        <div className="flex flex-col gap-4">
          {c.res.p.map((txt, i) => (
            <RichBodyL key={i} html={txt} />
          ))}
        </div>
        <div className="mt-2 flex flex-col gap-3">
          <Micro>Begriffe zum Weiterdenken (antippen)</Micro>
          <div className="flex flex-wrap gap-2.5">
            {c.res.terms.map(([tid, label]) => (
              <motion.button
                key={tid}
                whileTap={{ scale: 0.95 }}
                onClick={() => toggleTerm(id, tid)}
                className={cn(
                  "min-h-10 cursor-pointer rounded-full border px-4 text-sm font-medium transition-all duration-200",
                  openT === tid
                    ? "border-acc/50 text-ink underline decoration-acc underline-offset-4"
                    : "border-line text-ink2 hover:border-line2 hover:text-ink"
                )}
              >
                {label}
              </motion.button>
            ))}
          </div>
          <AnimatePresence initial={false}>
            {c.res.terms.map(([tid, , q]) =>
              openT === tid ? (
                <motion.div
                  key={tid}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="rounded-r-xl border-l-[3px] border-l-acc bg-surface px-5 py-3.5 text-[15px] leading-6 text-ink2"
                >
                  → {q}
                </motion.div>
              ) : null
            )}
          </AnimatePresence>
        </div>
      </div>
    </Screen>
  );
}

export function CaseTrace({ id }: { id: number }) {
  const { go } = useApp();
  const c = CASES[id];
  return (
    <Screen
      label={`Case ${c.n} · EnergyTrace`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(`c${id}-res`)}
            icon={ArrowLeft}
          >
            Auflösung
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(`c${id}-done`)} icon={ArrowRight} iconRight>
            Case abschließen
          </Btn>
        </>
      }
    >
      <div className={stack}>
        <TraceView lanes={c.trace.lanes} />
        <CoreConclusion html={c.trace.concl} />
      </div>
    </Screen>
  );
}

export function CaseDone({ id }: { id: number }) {
  const { go } = useApp();
  const c = CASES[id];
  const nextR = id < 5 ? `c${id + 1}-start` : "summary";
  const nextLabel =
    id < 5 ? `Weiter zu Case 0${id + 1}` : "Zur Zusammenfassung aller Spuren";
  return (
    <Screen
      label={`Case ${c.n} · Abgeschlossen`}
      cn={id}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go(`c${id}-tra`)}
            icon={ArrowLeft}
          >
            Spur nochmals ansehen
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go(nextR)} icon={ArrowRight} iconRight>
            {nextLabel}
          </Btn>
        </>
      }
    >
      <div className={hero}>
        <HeroGlyph />
        <div className="flex w-full flex-col items-center gap-4">
          <Micro accent>Case 0{id} abgeschlossen</Micro>
          <Display>
            Spur <span className="serif-acc text-acc">gesichert.</span>
          </Display>
          <Learn k={`Die Spur aus Case 0${id}`} className="max-w-[620px] text-left">
            {c.done}
          </Learn>
        </div>
      </div>
    </Screen>
  );
}

/* ============================================================
   07 · ZUSAMMENFASSUNG
============================================================ */

function CustomForms() {
  const { state, addCustom, removeCustom } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dup, setDup] = useState(false);

  const submit = () => {
    const el = inputRef.current;
    if (!el) return;
    const value = el.value.trim();
    if (!value) {
      el.focus();
      return;
    }
    const ok = addCustom(value);
    if (!ok) {
      el.value = "";
      setDup(true);
      el.focus();
      return;
    }
    el.value = "";
    setDup(false);
    requestAnimationFrame(() => inputRef.current?.focus());
  };

  return (
    <div className="flex flex-col gap-4 rounded-3xl border border-line bg-surface p-6">
      <div className="flex flex-col gap-1.5">
        <Micro accent>07 · Eure Ergänzungen</Micro>
        <div className="text-[19px] font-bold leading-6.5">
          Welche weiteren Energieformen findet ihr?
        </div>
        <p className="text-[15px] leading-6 text-ink2">
          Die bisher gezeigten Begriffe sind keine abgeschlossene Liste. Tragt
          weitere Beschreibungen ein, die ihr kennt oder entdeckt.
        </p>
      </div>

      <div className="flex flex-col gap-2.5 sm:flex-row">
        <input
          ref={inputRef}
          type="text"
          maxLength={60}
          autoComplete="off"
          aria-label="Weitere Energieform eintragen"
          placeholder={
            dup
              ? "Dieser Begriff wurde bereits eingetragen."
              : "Zum Beispiel: Lageenergie"
          }
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              submit();
            }
          }}
          onChange={() => dup && setDup(false)}
          className={cn(
            "min-h-12 flex-1 rounded-full border bg-white/[0.03] px-5 text-[15px] text-ink outline-none transition-colors placeholder:text-ink3",
            dup
              ? "border-err/60 placeholder:text-err/70"
              : "border-line focus:border-acc/60"
          )}
        />
        <Btn variant="secondary" onClick={submit} icon={Plus}>
          Eintragen
        </Btn>
      </div>

      <div className="flex flex-wrap gap-2.5" aria-live="polite">
        <AnimatePresence initial={false}>
          {state.customForms.length ? (
            state.customForms.map((form, index) => (
              <motion.span
                key={`${form}-${index}`}
                layout
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
                className="group inline-flex min-h-10 items-center gap-2 rounded-full border border-acc/35 bg-acc/[0.07] py-0 pr-1.5 pl-4 text-sm font-medium text-ink"
              >
                {form}
                <button
                  onClick={() => removeCustom(index)}
                  aria-label={`${form} entfernen`}
                  title="Eintrag entfernen"
                  className="grid h-6 w-6 cursor-pointer place-items-center rounded-full text-ink3 transition-colors hover:bg-err/15 hover:text-err"
                >
                  <X size={13} strokeWidth={2.4} />
                </button>
              </motion.span>
            ))
          ) : (
            <div className="text-[14px] text-ink3">
              Noch keine eigenen Energieformen eingetragen.
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export function Summary() {
  const { state, go, toggleForm } = useApp();
  const openF = state.form;
  const cf = FORMS.find((f) => f.id === openF);

  return (
    <Screen
      label="Abschluss · Zusammenfassung"
      cn={5}
      footer={
        <>
          <Btn
            variant="secondary"
            onClick={() => go("c5-done")}
            icon={ArrowLeft}
          >
            Case 05
          </Btn>
          <FootSpacer />
          <Btn onClick={() => go("home")}>Zurück zum Startbildschirm</Btn>
        </>
      }
    >
      <div className={stack}>
        <div className="flex flex-col gap-2.5">
          <Micro accent>Gesamt-Zusammenfassung</Micro>
          <Display>
            Fünf Spuren. <span className="serif-acc text-acc">Ein Prinzip.</span>
          </Display>
          <BodyL className="max-w-[640px]">
            Ihr habt fünf völlig unterschiedliche Systeme untersucht. Alle
            führen zum selben physikalischen Kern.
          </BodyL>
        </div>

        <div className="grid grid-cols-1 gap-3.5 md:grid-cols-3">
          {[
            ["01", "Veränderung", "Energie ist die Fähigkeit, Veränderungen zu bewirken."],
            ["02", "Übertragung", "Energie wandert von einem System zum nächsten."],
            ["03", "Erhaltung", "Energie verschwindet nicht. Sie wird umgewandelt."],
          ].map(([n, t, d], i) => (
            <motion.div
              key={n}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08, duration: 0.45 }}
              className="rounded-3xl border border-line bg-surface p-5"
            >
              <div className="mb-2 text-[12px] font-bold text-acc">{n}</div>
              <div className="text-[18px] font-bold">{t}</div>
              <p className="mt-1.5 text-[15px] leading-6 text-ink2">{d}</p>
            </motion.div>
          ))}
        </div>

        <div className="flex flex-col gap-3.5">
          <Micro>Die Energieformen aus allen fünf Spuren (antippen)</Micro>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {FORMS.map((f, i) => (
              <motion.button
                key={f.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => toggleForm(f.id)}
                className={cn(
                  "flex min-h-[72px] cursor-pointer items-center gap-3.5 rounded-2xl border px-4.5 py-3 text-left transition-all duration-200",
                  openF === f.id
                    ? "border-acc/50 bg-surface2"
                    : "border-line bg-surface hover:bg-surface2"
                )}
              >
                <Sym kind="form" size={15} className="text-acc" />
                <div>
                  <div className="text-[15.5px] font-semibold">{f.t}</div>
                  <div className="mt-0.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink3">
                    {f.c}
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
          <AnimatePresence initial={false}>
            {cf && (
              <motion.div
                key={cf.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="rounded-r-xl border-l-[3px] border-l-acc bg-surface px-5 py-3.5 text-[15px] leading-6 text-ink2"
              >
                <strong className="font-semibold text-ink">{cf.t}:</strong>{" "}
                {cf.q}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <CustomForms />

        <Learn k="Der zentrale Gedanke">
          Energie wird nicht einfach verbraucht. Sie wird übertragen und
          umgewandelt.
        </Learn>
      </div>
    </Screen>
  );
}

export function NotFound() {
  const { go } = useApp();
  return (
    <Screen
      label="ENERGY TRACE"
      footer={<Btn onClick={() => go("home")}>Zum Start</Btn>}
    >
      <div className={hero}>
        <HeroGlyph />
        <Display>Diese Spur gibt es nicht.</Display>
      </div>
    </Screen>
  );
}


